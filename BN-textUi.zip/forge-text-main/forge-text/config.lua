Config = { }

Config.Style = {
    primaryBackground = 'linear-gradient(270deg, rgba(28, 28, 28, 0.675) 0%, rgba(255, 0, 102, 0.9) 98.22%)',
    primaryBorder = '#FF0066',
    secondaryBackground = '#282828',
    secondaryBorder = '#4F4F4F'
}