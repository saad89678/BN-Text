# forge-text
Text UI Script for ESX, QB and Standalone

![image](https://github.com/C0deForge/forge-text/assets/125872426/da353bc2-426c-4036-9592-abe4a962711d)

![image](https://github.com/C0deForge/forge-text/assets/125872426/63b5a858-c116-4632-9e02-68bb64fe5028)


